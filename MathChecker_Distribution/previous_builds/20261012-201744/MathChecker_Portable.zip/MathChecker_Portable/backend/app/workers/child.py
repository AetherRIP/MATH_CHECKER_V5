"""Worker child process bootstrap.

Run as:  python <backend>/app/workers/child.py      (a script, by path)
         python -m app.workers.child                (also works)

The orchestrator launches it by PATH on purpose: the packaged application runs
on CPython's embeddable distribution, whose ``python313._pth`` file makes
CPython ignore PYTHONPATH, so a ``-m`` module launch cannot find the ``app``
package there and the child dies before it reads its job.

Reads one JSON job descriptor from stdin, executes the trusted correction
engine, writes one JSON result to stdout. This avoids multiprocessing.spawn's
``__main__`` re-import entirely (which breaks under pytest and frozen apps)
while keeping full process isolation — the child has its own memory, its own
interpreter state, and only stdin/stdout as the IPC channel.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

# Make the backend package importable no matter the cwd or how this file was
# started: ``app`` lives one level ABOVE app/workers, so the backend root goes
# on sys.path (this is what ``from app.… import …`` below needs).
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))


class _UsageModels:
    """Record one generation round-trip per call (response exact, request
    overhead estimated). Accounting is best-effort and never breaks marking."""

    def __init__(self, inner, job_id=None):
        self._inner = inner
        self._job_id = job_id

    def generate_content(self, *args, **kwargs):
        from app.net_usage import GENERATION_REQUEST_OVERHEAD_BYTES, record
        response = self._inner.generate_content(*args, **kwargs)
        try:
            text = getattr(response, "text", "") or ""
            record("gemini_generate", GENERATION_REQUEST_OVERHEAD_BYTES, len(text))
            from app.api_stats import record_job_bandwidth
            record_job_bandwidth(self._job_id, ai_attempts=1)
        except Exception:
            pass
        return response

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _UsageFiles:
    """Record exact uploaded file bytes (the dominant correction traffic)."""

    def __init__(self, inner):
        self._inner = inner

    def upload(self, *args, **kwargs):
        from app.net_usage import record
        path = kwargs.get("file") or (args[0] if args else None)
        remote = self._inner.upload(*args, **kwargs)
        try:
            size = os.path.getsize(path) if path else 0
            record("gemini_upload", size, 0)
        except Exception:
            pass
        return remote

    def get(self, *args, **kwargs):
        return self._inner.get(*args, **kwargs)

    def delete(self, *args, **kwargs):
        return self._inner.delete(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _UsageRecordingClient:
    """Transparent wrapper: identical client surface, plus usage accounting.
    The trusted engine is unaware of it."""

    def __init__(self, inner, job_id=None):
        object.__setattr__(self, "_inner_client", inner)
        self.models = _UsageModels(inner.models, job_id)
        # KeyAwareClient records uploads itself (exact bytes, once). Wrapping
        # it again would double-count the dominant correction traffic.
        self.files = inner.files if getattr(inner, "records_usage", False) \
            else _UsageFiles(inner.files)

    def __getattr__(self, name):
        return getattr(self._inner_client, name)


def _run(job: dict) -> dict:
    started = time.time()
    from app.engine.legacy_marking import (  # trusted engine (verbatim)
        audit_result, calculate_totals, grade_with_model, make_group_rows,
        normalise_result, percentage_band_grade,
    )
    from app.engine import double_check
    from app.engine.blueprint import apply_blueprint, get_blueprint
    from app.engine import model_health_store as mhs
    from app.config import get_config

    # Restore shared model health + the pinned marking model so the model
    # chain does not restart from scratch in every worker process (otherwise
    # the model that marks a submission is a per-job lottery).
    mhs.load()

    submission_paths = job["submission_paths"]
    mark_scheme_path = job.get("mark_scheme_path")
    question_paper_path = job.get("question_paper_path")

    # Mock/demo mode travels with the job because this child is a separate
    # interpreter that re-reads config.toml (which does not record the
    # in-memory demo flag). Applying it here keeps blueprint extraction and
    # the client selection consistent with the orchestrator.
    if job.get("mock"):
        get_config().mock_mode = True

    if get_config().mock_mode:
        from app.gemini.mock import MockGeminiClient
        client = MockGeminiClient()
        inner_client = None
    else:
        # Multi-key rotation INSIDE the job: the pool leases one key for this
        # job (preferred_fp), but a mid-job 429/invalid key now rotates to
        # another healthy key instead of forcing the model-fallback chain onto
        # a different model (a major source of run-to-run mark differences).
        # Outcomes are recorded through the KeyManager, so the KEY_n stats and
        # cooldowns stay truthful across processes (WAL SQLite).
        from app.gemini.client_proxy import KeyAwareClient
        from app.gemini.key_manager import KeyManager
        inner_client = KeyAwareClient(
            KeyManager(), preferred_fp=job.get("leased_fingerprint"),
            job_id=job.get("job_id"))
        client = _UsageRecordingClient(inner_client, job.get("job_id"))

    def _upload(path, purpose: str = "submission"):
        if not path:
            return None
        # upload_file waits for the remote file to become ACTIVE (legacy
        # PROCESSING poll loop lives in the key-aware client) and reuses a
        # registered remote when one is still alive (§6/§9). Mark schemes are
        # SHARED: uploaded once, then reused by every sibling job.
        if inner_client is not None:
            return inner_client.upload_file(
                path, purpose=purpose, shared=(purpose == "mark_scheme"))
        return client.files.upload(file=path)

    remote_students = [_upload(p, "submission") for p in submission_paths]
    remote_scheme = _upload(mark_scheme_path, "mark_scheme")
    remote_question = _upload(question_paper_path, "question")

    try:
        # Mark-scheme blueprint: official question structure, extracted once
        # per mark-scheme file and cached — question numbering and maximum
        # marks therefore do not change between runs of the same mark scheme.
        blueprint, blueprint_meta = (None, {"source": "unavailable"})
        if mark_scheme_path:
            blueprint, blueprint_meta = get_blueprint(client, mark_scheme_path)

        model_chain = mhs.ordered_models(job["primary_models"])
        raw, marking_model = grade_with_model(
            client=client,
            model_names=model_chain,
            student_file=remote_students,
            mark_scheme_file=remote_scheme,
            question_file=remote_question,
            status_callback=None,
            blueprint=blueprint,
        )
        mhs.record_success(marking_model, model_chain)
        mhs.save()
        result = normalise_result(raw)
        result, blueprint_report = apply_blueprint(result, blueprint)
        blueprint_report["source"] = blueprint_meta.get("source", "unavailable")
        if blueprint_meta.get("error"):
            blueprint_report["note"] = blueprint_meta["error"]

        # ---- explicit per-question states ----------------------------------
        # Missing mark-scheme questions become NEEDS_REVIEW (not a silent 0)
        # and evidence-backed zeros are labelled CONFIRMED_ZERO. Mirrors the
        # Large PDF Runner; the pool may then recover the gap narrowly.
        from app.engine.question_inventory import (
            confirmed_zero_status, mark_missing_results,
        )
        mark_missing_results(result)
        for q in result.get("questions", []):
            if confirmed_zero_status(q) == "CONFIRMED_ZERO" and not q.get("status"):
                q["status"] = "CONFIRMED_ZERO"

        # ---- targeted recovery of the missing questions ---------------------
        # Before anything is persisted: the remote files are still alive here,
        # so re-marking ONLY the missing questions costs no re-upload and no
        # re-marking of the successful rows. Bounded: one round per child run,
        # and only for a gap small enough to be a marker omission (a large
        # gap means the mark-scheme blueprint itself is incomplete, and the
        # questions stay NEEDS_REVIEW for the teacher).
        recovery_record = None
        try:
            from app.engine import recover_missing
            missing_here = list(blueprint_report.get("missing_questions") or [])
            may_retry, block_reason = recover_missing.need_recovery(
                missing=missing_here, already_attempted=0)
            if may_retry:
                outcome = recover_missing.run_recovery_round(
                    client=client, missing=missing_here,
                    student_remote=remote_students,
                    mark_scheme_remote=remote_scheme,
                    question_remote=remote_question,
                    mark_scheme_path=mark_scheme_path,
                )
                recovery_record = {
                    "rounds": 1,
                    "missing_reported": missing_here,
                    "recovered": sorted(outcome.recovered),
                    "still_missing": list(outcome.still_missing),
                    "error": outcome.error,
                }
                if outcome.recovered:
                    from app.engine.question_inventory import canonical_question_id
                    by_canon = {
                        canonical_question_id(
                            str(q.get("question_number", ""))): q
                        for q in result.get("questions", [])
                    }
                    for canon, row in outcome.recovered.items():
                        placeholder = by_canon.get(canon)
                        if placeholder is not None and \
                                str(placeholder.get("status", "")).upper() in (
                                    "REVIEW", "NEEDS_REVIEW", "UNMARKED"):
                            placeholder.clear()
                            placeholder.update(row)
                    result, blueprint_report = apply_blueprint(result, blueprint)
                    blueprint_report["source"] = blueprint_meta.get(
                        "source", "unavailable")
                    mark_missing_results(result)
                    for q in result.get("questions", []):
                        if confirmed_zero_status(q) == "CONFIRMED_ZERO" \
                                and not q.get("status"):
                            q["status"] = "CONFIRMED_ZERO"
                from app.logging_setup import log_event as _log
                _log("workers.child", "targeted recovery finished",
                     run_id=job["job_id"],
                    recovered=recovery_record["recovered"],
                    still_missing=recovery_record["still_missing"],
                    error=recovery_record["error"])
            elif block_reason:
                recovery_record = {"rounds": 0, "missing_reported":
                                   list(blueprint_report.get(
                                       "missing_questions") or []),
                                   "recovered": [], "still_missing": [],
                                   "error": block_reason}
        except Exception as recovery_exc:  # noqa: BLE001 — never lose the job
            recovery_record = {"rounds": 0, "error": str(recovery_exc)[:500]}
        if recovery_record is not None:
            blueprint_report["recovery"] = recovery_record

        audit_model = "Not run"
        audit_warning = None
        if job.get("audit_enabled"):
            try:
                audited, audit_model = audit_result(
                    client=client, result=result,
                    student_file=remote_students,
                    mark_scheme_file=remote_scheme,
                    model_names=job["primary_models"][:2],
                )
                result = normalise_result(audited)
                result, blueprint_report = apply_blueprint(result, blueprint)
            except Exception as audit_error:
                audit_warning = str(audit_error)

        earned, available, percentage = calculate_totals(result)
        totals = {
            "earned": earned,
            "available": available,
            "percentage": percentage,
            "provisional_grade": percentage_band_grade(percentage),
        }

        # ---- High-score double-check (independent second correction) ------
        # Triggered by the FIRST correction's unrounded percentage only (§2).
        # The second pass re-runs the SAME trusted engine on the SAME original
        # submission + mark scheme — it never sees the first score, reasoning,
        # report or confidence, so it is a genuinely independent evaluation
        # (§3/§10). A distinct sampling seed prevents a deterministic replay
        # of the first pass. The remote files are still uploaded, so the
        # second pass costs generation requests only (§14: it never runs for
        # scores below the threshold).
        second_result = None
        second_marking_model = None
        dc_triggered = False
        dc_error = None
        if job.get("double_check_enabled", True) and \
                double_check.should_trigger(earned, available):
            dc_triggered = True
            try:
                raw2, second_marking_model = grade_with_model(
                    client=client,
                    # A different model leads the second pass when one is
                    # available: at temperature 0 the same model tends to
                    # replay the first pass's marks, which would make the
                    # check a confirmation by construction (§4).
                    model_names=double_check.second_pass_models(
                        model_chain, marking_model),
                    student_file=remote_students,
                    mark_scheme_file=remote_scheme,
                    question_file=remote_question,
                    status_callback=None,
                    blueprint=blueprint,
                    sampling=double_check.SECOND_PASS_SAMPLING,
                )
                second_result = normalise_result(raw2)
                second_result, _ = apply_blueprint(second_result, blueprint)
            except Exception as exc:  # noqa: BLE001 — a failed check must not
                # discard the valid first correction (§13).
                dc_error = str(exc)[:800]
                second_result = None
            from app.logging_setup import log_event as _log
            _log("workers.child", "double-check finished",
                 run_id=job["job_id"],
                 first=earned, available=available,
                 second=(calculate_totals(second_result)[0]
                         if second_result is not None else None),
                 status=("COMPLETE" if second_result is not None
                         else "FAILED"),
                 triggered=dc_triggered)

        groups = make_group_rows(result["questions"])

        key_fp = inner_client.current_fingerprint() if inner_client else None
        if inner_client is not None:
            from app.logging_setup import log_event
            log_event("workers.child", "correction finished",
                      run_id=job["job_id"], model=marking_model,
                      fingerprint=key_fp,
                      blueprint_source=blueprint_report.get("source"),
                      earned=earned, available=available,
                      processing_s=round(time.time() - started, 1))

        return {
            "job_id": job["job_id"], "worker_id": job["worker_id"],
            "status": "COMPLETED", "ok": True, "result": result,
            "totals": totals, "groups": groups,
            "marking_model": marking_model, "audit_model": audit_model,
            "audit_warning": audit_warning,
            "blueprint_report": blueprint_report,
            "key_fingerprint": key_fp,
            "key_recorded": inner_client is not None,
            "processing_seconds": round(time.time() - started, 2),
            "double_check_triggered": dc_triggered,
            "second_result": second_result,
            "second_marking_model": second_marking_model,
            "double_check_error": dc_error,
        }
    finally:
        if inner_client is not None:
            # Do NOT delete the uploads: an AI failure retried by the pool must
            # reuse them instead of re-uploading the student's submission.
            # The pool deletes them at the job's terminal state.
            try:
                inner_client.release_job_files()
            except Exception:
                pass
        else:
            for remote in [*remote_students, remote_scheme, remote_question]:
                if remote is not None:
                    try:
                        client.files.delete(name=remote.name)
                    except Exception:
                        pass


def main() -> int:
    # Structured logs (run id / model / safe key fingerprint / blueprint
    # source) go to data/logs/app.log — credentials are redacted by the
    # logging filter; stderr is discarded by the worker pool.
    try:
        from app.logging_setup import setup_logging
        setup_logging()
    except Exception:
        pass

    raw = sys.stdin.read()
    try:
        job = json.loads(raw)
    except json.JSONDecodeError as exc:
        json.dump({"ok": False, "status": "FAILED",
                   "error": f"Bad job descriptor: {exc}"}, sys.stdout)
        return 1

    try:
        payload = _run(job)
    except KeyboardInterrupt:
        payload = {"job_id": job.get("job_id"), "worker_id": job.get("worker_id"),
                   "status": "CANCELLED", "ok": False, "error": "Cancelled"}
    except Exception as exc:
        from app.errors import classify_gemini_error
        payload = {"job_id": job.get("job_id"), "worker_id": job.get("worker_id"),
                   "status": "FAILED", "ok": False,
                   "error": str(exc)[:800],
                   "error_kind": classify_gemini_error(exc)["kind"]}

    json.dump(payload, sys.stdout, ensure_ascii=False, default=str)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
