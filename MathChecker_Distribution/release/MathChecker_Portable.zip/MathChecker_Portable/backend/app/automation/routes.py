"""REST API for the automated correction workflow (§7, §43, §44, §45, §46)."""

from __future__ import annotations

import time

from fastapi import APIRouter, Request

from .. import auth_gate, db
from ..config import AUTOMATION_INTERVALS, get_config, save_config
from ..errors import AppError
from ..logging_setup import log_event
from . import states, store
from .scheduler import AutomationSchedulerHolder

router = APIRouter(prefix="/api/automation")


def _scheduler():
    return AutomationSchedulerHolder.instance()


def _batched_keys() -> tuple[set[tuple], set[str]]:
    """Which submissions the LARGE-PDF pipeline actually handled (§8).

    Read from the real ``large_pdf_jobs`` rows rather than inferred: a
    submission that the router sent to the batched worker has a row there, and
    nothing else does. Two keys are collected because a Classroom job and a
    manual upload are identified differently.
    """
    rows = db.query(
        "SELECT coursework_id, submission_id, result_id FROM large_pdf_jobs "
        "WHERE status != 'CANCELLED'")
    pairs = {(r["coursework_id"], r["submission_id"]) for r in rows
             if r["coursework_id"] and r["submission_id"]}
    results = {r["result_id"] for r in rows if r["result_id"]}
    return pairs, results


def _pipeline_of(job: dict, batched: tuple[set[tuple], set[str]]) -> str | None:
    """The pipeline that handled this job: 'batched', 'standard' or unknown.

    ``None`` means the job has not reached correction yet, so claiming either
    pipeline would be a guess.
    """
    pairs, results = batched
    if job.get("result_id") and job["result_id"] in results:
        return "batched"
    key = (job.get("coursework_id"), job.get("submission_id"))
    if key[0] and key[1] and key in pairs:
        return "batched"
    if job.get("correction_job_id") or job.get("result_id"):
        return "standard"
    return None


def _job_public(job: dict, batched: tuple[set[tuple], set[str]] | None = None) -> dict:
    # One shared decision: a retry is possible exactly when the runner says so.
    resume = states.retry_step(job)
    resumable = resume is not None
    if batched is None:
        batched = _batched_keys()
    return {
        **job,
        #: Which REAL pipeline corrected (or is correcting) this submission.
        "pipeline": _pipeline_of(job, batched),
        "pipeline_label": {"batched": "Batched large-PDF pipeline",
                           "standard": "Standard single-pass pipeline"
                           }.get(_pipeline_of(job, batched), None),
        "status_label": states.label(job["status"]),
        "stage_index": states.stage_index(job["status"]),
        # The SAME rule the runner enforces, so the Retry button and the
        # backend can never disagree about whether a retry is possible.
        "resumable": resumable,
        #: Where a retry would resume, so the UI can say WHAT it is retrying.
        "retry_from": states.label(resume) if resume else None,
        # The report is only "uploaded" once a verified Drive file id is on
        # the job - the UI must never show a tick without that evidence.
        "has_result": bool(job.get("result_id")),
        "report_uploaded": bool(job.get("drive_file_id")),
        # Review mode (and engine review flags) park a job with a verified
        # result + grade, waiting for a teacher. These two flags drive the
        # Approve button in the UI.
        "awaiting_approval": (
            job["status"] == states.ATTENTION_REQUIRED
            and job.get("error_code") == "review_mode_await_teacher"),
        "approvable": bool(
            job.get("result_id") and job.get("grade")
            and job["status"] in (states.ATTENTION_REQUIRED,
                                  states.GRADE_VERIFIED,
                                  states.GRADE_DRAFTED)),
    }


@router.get("/status")
def automation_status():
    """Everything the Automation page needs to render (§7, §43)."""
    scheduler = _scheduler()
    status = scheduler.status()
    return {
        **status,
        "intervals": list(AUTOMATION_INTERVALS),
        "pipeline": [{"state": s, "label": states.label(s)} for s in states.PIPELINE],
    }


@router.post("/worker")
def worker_control(payload: dict, request: Request):
    """Background Worker ON/OFF (§3) — the real backend switch.

    Turning the worker OFF stops NEW automatic correction jobs from starting
    (detection stops and never-started jobs stay queued) while jobs already
    in flight finish normally; the website, manual AI correction and the
    tiny networking agent are untouched. The preference is persisted to
    ``config.toml`` before anything else, so an ordinary restart cannot
    silently turn the worker back on.

    Turning it ON re-checks that the scheduler thread is actually alive and
    reports the verified state — the response is always the backend's real
    state, never an echo of the requested value.
    """
    auth_gate.require_permission(request, "automation.manage")
    desired = bool(payload.get("enabled"))
    cfg = get_config()
    changed = bool(cfg.automation.enabled) != desired
    if changed:
        cfg.automation.enabled = desired
        save_config(cfg)          # persist BEFORE acting (survives restart)

    scheduler = _scheduler()
    if desired:
        # Wake immediately: queued (NEW) jobs resume without waiting a cycle.
        store.set_meta("next_check", 0.0)
        scheduler.start()         # idempotent — never a second thread
        scheduler.wake()
        if not scheduler.running():
            raise AppError(
                "The background worker did not start. Check the server log "
                "(Diagnostics → Logs) — automation is enabled but no scheduler "
                "thread is running.", status=500, code="worker_start_failed")
    else:
        # Keep the thread alive so in-flight jobs advance to a safe stop.
        store.set_meta("next_check", time.time())
        scheduler.wake()

    state = scheduler.status()
    log_event("automation", "background worker " + ("turned on" if desired else "turned off"),
              state=state.get("worker_state"),
              pending=state.get("pending_jobs"), active=state.get("active_jobs"))
    return {**state, "updated": ["enabled"] if changed else [],
            "requested": desired}


@router.post("/settings")
def update_settings(payload: dict, request: Request):
    """Enable/disable automation and choose the polling interval (§4, §45).

    Disabling automation stops future polling but NEVER destroys queued jobs
    or completed results.
    """
    auth_gate.require_permission(request, "automation.manage")
    cfg = get_config()
    changed = []
    if "enabled" in payload:
        cfg.automation.enabled = bool(payload["enabled"])
        changed.append("enabled")
    if "interval_minutes" in payload:
        try:
            interval = int(payload["interval_minutes"])
        except (TypeError, ValueError):
            raise AppError("interval_minutes must be a number.", status=400,
                           code="bad_interval")
        if interval not in AUTOMATION_INTERVALS:
            raise AppError(
                "interval_minutes must be one of "
                f"{', '.join(str(i) for i in AUTOMATION_INTERVALS)}.",
                status=400, code="bad_interval")
        cfg.automation.interval_minutes = interval
        changed.append("interval_minutes")
    for key in ("attach_report", "submit_grade", "return_work", "draft_only",
                "review_mode"):
        if key in payload:
            setattr(cfg.automation, key, bool(payload[key]))
            changed.append(key)
    if payload.get("report_detail") in ("summary", "standard", "detailed"):
        cfg.automation.report_detail = payload["report_detail"]
        changed.append("report_detail")
    save_config(cfg)
    if "interval_minutes" in changed or "enabled" in changed:
        # Recompute the next check from now so a changed interval takes effect
        # immediately instead of after the old (possibly long) interval.
        import time
        store.set_meta("next_check", 0.0 if cfg.automation.enabled
                       else time.time())
    _scheduler().wake()
    return {**_scheduler().status(), "updated": changed}


@router.get("/assignments")
def list_assignments():
    """Per-assignment automation selection + live statistics (§43, §46)."""
    enabled = store.enabled_map()
    rows = db.query(
        "SELECT id, course_id, title, max_points, allowlisted, sync_state, "
        "custom_title, classroom_title FROM coursework ORDER BY title")
    stats = _assignment_stats()
    out = []
    for row in rows:
        cw = row["id"]
        setting = enabled.get(cw)
        stat = stats.get(cw, {})
        deleted = (row["sync_state"] == "DELETED_IN_CLASSROOM")
        out.append({
            "coursework_id": cw,
            "course_id": row["course_id"],
            "title": row["title"],
            "classroom_title": row["classroom_title"],
            "custom_title": row["custom_title"],
            "sync_state": row["sync_state"] or "ACTIVE",
            # Never selectable/monitored once deleted in Classroom.
            "deleted_in_classroom": deleted,
            "max_points": row["max_points"],
            "enabled": bool(setting and setting["enabled"]) and not deleted,
            "last_checked_at": setting["last_checked_at"] if setting else None,
            "last_error": setting["last_error"] if setting else None,
            "markscheme": _has_mark_scheme(cw),
            "stats": stat,
        })
    return {"assignments": out, "enabled_count":
            sum(1 for a in out if a["enabled"])}


def _assignment_stats() -> dict[str, dict]:
    rows = db.query(
        "SELECT coursework_id, status, COUNT(*) AS n FROM automation_jobs "
        "GROUP BY coursework_id, status")
    out: dict[str, dict] = {}
    for row in rows:
        bucket = out.setdefault(row["coursework_id"], {
            "submitted": 0, "completed": 0, "processing": 0, "waiting": 0,
            "failed": 0, "total": 0})
        status, n = row["status"], row["n"]
        bucket["total"] += n
        if status == states.COMPLETE:
            bucket["completed"] += n
        elif status in states.RETRYABLE_FAILURES:
            bucket["failed"] += n
            bucket["waiting"] += n
        elif status in states.NEEDS_ATTENTION:
            bucket["failed"] += n
        elif status == states.NEW:
            bucket["submitted"] += n
            bucket["waiting"] += n
        else:
            bucket["processing"] += n
    return out


def _has_mark_scheme(coursework_id: str) -> bool:
    from pathlib import Path
    from ..config import DATA_DIR
    if (DATA_DIR / "mark_schemes" / f"{coursework_id}.pdf").exists():
        return True
    row = db.query_one(
        "SELECT path FROM pending_mark_schemes WHERE coursework_id = ?",
        (coursework_id,))
    return bool(row and row["path"] and Path(row["path"]).exists())


@router.post("/assignments/{coursework_id}")
def set_assignment(coursework_id: str, payload: dict):
    """Enable or disable automatic correction for ONE assignment (§3, §46)."""
    cw = db.query_one("SELECT * FROM coursework WHERE id = ?", (coursework_id,))
    if not cw:
        raise AppError("Assignment not found. Sync Google Classroom first.",
                       status=404, code="not_found")
    enabled = bool(payload.get("enabled"))
    if enabled and (cw["sync_state"] or "ACTIVE") == "DELETED_IN_CLASSROOM":
        raise AppError(
            "This assignment was deleted in Google Classroom, so it cannot be "
            "monitored. Re-create it in Classroom to resume automation.",
            status=409, code="deleted_in_classroom")
    record = store.set_assignment_enabled(coursework_id, cw["course_id"], enabled)
    _scheduler().wake()
    return {"coursework_id": coursework_id, "enabled": enabled,
            "assignment": record}


@router.get("/jobs")
def list_jobs(status: str | None = None, coursework_id: str | None = None,
              limit: int = 100):
    statuses = [s.strip().upper() for s in status.split(",")] if status else None
    jobs = store.list_jobs(statuses=statuses, coursework_id=coursework_id,
                           limit=min(500, max(1, limit)))
    # ONE lookup for the whole page, not one query per row.
    batched = _batched_keys()
    return {"jobs": [_job_public(j, batched) for j in jobs]}


@router.get("/jobs/{job_id}")
def job_detail(job_id: str):
    job = store.get(job_id)
    if not job:
        raise AppError("Automation job not found.", status=404, code="not_found")
    result = None
    if job.get("result_id"):
        result = db.row_to_dict(db.query_one(
            "SELECT id, earned, available, percentage, provisional_grade, "
            "review_required, manual_override, double_check_triggered, "
            "double_check_status, double_check_reason, disagreement_status, "
            "first_earned, first_available, second_earned, second_available, "
            "confidence, confidence_reasons FROM results WHERE id = ?",
            (job["result_id"],)))
    # The REAL per-stage report/attachment state (status, error, drive id,
    # lifecycle). The UI shows this rather than inferring from the job status.
    attachment = None
    if job.get("result_id"):
        try:
            from ..classroom import report_attachment as ra
            attachment = ra.get_state(job["result_id"])
        except Exception:  # noqa: BLE001 - detail must never break the page
            attachment = None
    return {**_job_public(job), "result": result, "attachment": attachment,
            "publication": _publication(job, attachment)}


def _publication(job: dict, attachment: dict | None) -> dict:
    """Honest per-stage publication status for the review UI (§6).

    Google Classroom operations are separate API calls, so each stage is
    reported individually: a teacher can see exactly which part succeeded and
    which still needs to run. Nothing here is inferred from an intention —
    only from the recorded job state and the verified attachment record.
    """
    status = job.get("status")
    attached = bool(attachment and attachment.get("attached"))
    attach_status = (attachment or {}).get("status")
    failed_statuses = {"UPLOAD_FAILED", "DRIVE_VERIFY_FAILED",
                       "ATTACH_FAILED", "VERIFY_FAILED", "OWNERSHIP_ERROR"}
    if attached:
        report = "sent"
    elif attach_status in failed_statuses:
        report = "failed"
    elif attach_status:
        report = str(attach_status)
    else:
        report = "held_for_approval" if status == states.ATTENTION_REQUIRED \
            else "pending"
    grade_published = status in (states.RETURNING, states.RETURNED,
                                 states.COMPLETE)
    return {
        "report": report,
        "report_sent": attached,
        "grade": "published" if grade_published else
                 ("pending" if status == states.ATTENTION_REQUIRED else
                  str(job.get("grade") or "pending")),
        "grade_published": grade_published,
        "returned": status in (states.RETURNED, states.COMPLETE),
        "awaiting_approval": (
            status == states.ATTENTION_REQUIRED
            and job.get("error_code") == "review_mode_await_teacher"),
        "complete": status == states.COMPLETE,
    }


@router.post("/jobs/{job_id}/approve")
def approve_job(job_id: str):
    """Teacher approval: publish the FINAL grade and return the work.

    The explicit human decision that review mode holds a correction for. It
    reuses the same verified grade/return operations as the automatic path, so
    the AI is never re-run and the mark is never recomputed.
    """
    from .runner import StepFailure, runner
    job = store.get(job_id)
    if not job:
        raise AppError("Automation job not found.", status=404, code="not_found")
    try:
        updated = runner().approve(job_id)
    except StepFailure as exc:
        # Keep the runner's own code (no_result / grade_unavailable /
        # not_approvable) so the UI can say WHY, not just "failed".
        raise AppError(str(exc), status=409, code=exc.code)
    _scheduler().wake()
    return _job_public(updated or job)


@router.post("/jobs/{job_id}/retry")
def retry_job(job_id: str):
    """Retry a failed job from the step that failed — never from scratch.

    A job a retry cannot help (still running, already finished, or waiting for
    the teacher's decision) is REFUSED with 409 and the reason, so the button
    can never report a retry that did not happen.
    """
    from .runner import StepFailure, runner
    job = store.get(job_id)
    if not job:
        raise AppError("Automation job not found.", status=404, code="not_found")
    try:
        updated = runner().retry(job_id)
    except StepFailure as exc:
        raise AppError(str(exc), status=409, code=exc.code)
    _scheduler().wake()
    return _job_public(updated or job)


@router.post("/jobs/{job_id}/retry-report")
def retry_report(job_id: str):
    """Repair ONLY the report upload/attachment for a job.

    Never re-runs the AI correction and never re-computes the grade, so it is
    safe even on a job already marked COMPLETE whose report was not actually
    uploaded. Cheap enough to run synchronously, so the result comes straight
    back to the button that triggered it.
    """
    from .runner import runner
    job = store.get(job_id)
    if not job:
        raise AppError("Automation job not found.", status=404, code="not_found")
    if not job.get("result_id"):
        raise AppError("This job has no correction result to attach a report to.",
                       status=409, code="no_result")
    updated = runner().retry_report(job_id)
    _scheduler().wake()
    return _job_public(updated or job)


@router.post("/run-now")
def run_now():
    """Run one detection cycle + advance jobs immediately (teacher-triggered)."""
    scheduler = _scheduler()
    summary = scheduler.run_cycle()
    from .runner import runner
    runner().run_pending(max_jobs=25)
    return {**scheduler.status(), "cycle": summary}


@router.get("/log")
def recent_log(limit: int = 100):
    """Recent automation activity (§44) — no secrets are ever recorded."""
    return {"entries": store.recent_log(limit=min(500, max(1, limit)))}


@router.get("/assignment-naming")
def get_assignment_naming():
    """The OPTIONAL default display-name template for new assignments.

    All fields default to empty: the original Classroom name is preserved
    exactly unless the teacher deliberately configures a change.
    """
    from ..classroom import naming
    return {
        **naming.naming_defaults(),
        "reserved_text": naming.RESERVED_AUTO_TEXT,
        "note": ("No prefix or suffix is ever added automatically. With every "
                 "field empty the original Classroom name is kept exactly."),
    }


@router.post("/assignment-naming")
def set_assignment_naming(payload: dict):
    """Configure the default display-name template (nothing is forced)."""
    cfg = get_config()
    mode = str(payload.get("mode", cfg.assignment_naming.mode))
    cfg.assignment_naming.mode = mode if mode in ("original", "custom") \
        else "original"
    for key in ("custom_name", "prefix", "suffix"):
        if key in payload:
            setattr(cfg.assignment_naming, key, str(payload.get(key) or ""))
    save_config(cfg)
    from ..classroom import naming
    return {**naming.naming_defaults(), "updated": True}


@router.post("/assignments/{coursework_id}/name")
def rename_assignment(coursework_id: str, payload: dict):
    """Change ONE assignment's displayed Classroom name, verified.

    Internal identity (course/coursework id, original name) is untouched; only
    the display name the teacher sees is changed, and only if Google confirms.
    """
    row = db.query_one("SELECT course_id, title FROM coursework WHERE id = ?",
                       (coursework_id,))
    course_id = payload.get("course_id") or (row["course_id"] if row else None)
    if not course_id:
        raise AppError("Unknown assignment — sync Google Classroom first.",
                       status=404, code="not_found")
    display_name = payload.get("display_name")
    if not str(display_name or "").strip():
        raise AppError("A display name is required.", status=400,
                       code="empty_name")
    from ..classroom import client as gc
    from ..classroom import naming
    try:
        return naming.rename_coursework(coursework_id, course_id,
                                        str(display_name))
    except ValueError as exc:
        raise AppError(str(exc), status=400, code="empty_name")
    except gc.ClassroomApiError as exc:
        raise AppError(
            f"Google refused the rename ({exc.status}). {exc.detail or ''}"[:400],
            status=502, code="rename_failed")


@router.get("/grade-boundaries/{coursework_id}")
def get_grade_boundaries(coursework_id: str):
    boundaries, source = store.grade_boundaries(coursework_id)
    return {"coursework_id": coursework_id, "source": source,
            "boundaries": [[g, m] for g, m in boundaries]}


@router.post("/grade-boundaries/{coursework_id}")
def set_assignment_grade_boundaries(coursework_id: str, payload: dict):
    """Set assignment-specific IGCSE 1-9 boundaries (§20, §21)."""
    raw = payload.get("boundaries")
    parsed: list[tuple[str, float]] = []
    if isinstance(raw, list):
        for entry in raw:
            if not isinstance(entry, (list, tuple)) or len(entry) != 2:
                continue
            try:
                parsed.append((str(entry[0]).strip(), float(entry[1])))
            except (TypeError, ValueError):
                continue
    from .grading import _valid_boundaries
    if not _valid_boundaries(parsed):
        raise AppError(
            "Boundaries must be a valid IGCSE 1-9 table: (grade, minimum "
            "percentage) pairs including a grade reachable at 0%.",
            status=400, code="invalid_boundaries")
    store.set_grade_boundaries(coursework_id, parsed,
                               payload.get("session_label"))
    return {"coursework_id": coursework_id, "boundaries": [[g, m] for g, m in parsed]}
